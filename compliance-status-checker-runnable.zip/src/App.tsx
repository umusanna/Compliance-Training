/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  BusinessProfile,
  Learner,
  AuditChecklistItem,
  Course,
  LearnerCourseRecord,
  UserRole,
} from './types';
import { SECTOR_SPECIFIC_CHECKLISTS } from './data/initialChecklists';
import { COURSES_CATALOG, SECTOR_METADATA } from './data/regulatoryStandards';
import { runComplianceAudit } from './utils/complianceEngine';
import { api } from './services/api';
import { useToast } from './context/ToastContext';

import { Header } from './components/Header';
import { AuditOverview } from './components/AuditOverview';
import { BusinessProfileView } from './components/BusinessProfileView';
import { ManagerChecklistsView } from './components/ManagerChecklistsView';
import { LearnersRegisterView } from './components/LearnersRegisterView';
import { TrainingSolutionsView } from './components/TrainingSolutionsView';
import { AdminPortfolioView } from './components/AdminPortfolioView';
import { AdminRegulatoryView } from './components/AdminRegulatoryView';
import { LearnerModal } from './components/LearnerModal';
import { EnrolCourseModal } from './components/EnrolCourseModal';
import { AuditReportModal } from './components/AuditReportModal';
import { GuidedOnboardingModal } from './components/modals/GuidedOnboardingModal';

type Tab =
  | 'overview'
  | 'business'
  | 'checklists'
  | 'learners'
  | 'solutions'
  | 'portfolio'
  | 'regulatory';

const DEFAULT_BUSINESS_ID = 'biz-the-copper-kettle';

export default function App() {
  const { showToast } = useToast();

  // Portfolio (for the business switcher in the header)
  const [businesses, setBusinesses] = useState<BusinessProfile[]>([]);

  // Primary Application State — all sourced from the SQLite-backed API
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [learners, setLearners] = useState<Learner[]>([]);
  const [checklists, setChecklists] = useState<AuditChecklistItem[]>([]);

  const [isLoadingApp, setIsLoadingApp] = useState(true);
  const [isLoadingBusiness, setIsLoadingBusiness] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [currentRole, setCurrentRole] = useState<UserRole>('business_manager');

  // Modal States
  const [showReportModal, setShowReportModal] = useState(false);
  const [showLearnerModal, setShowLearnerModal] = useState(false);
  const [editingLearner, setEditingLearner] = useState<Learner | null>(null);
  const [selectedLearnerForEnrol, setSelectedLearnerForEnrol] = useState<Learner | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);

  // ---------------------------------------------------------------------
  // Data loading — this is the piece that used to be missing entirely.
  // Everything below reads from / writes to the Express + SQLite backend
  // instead of the hardcoded SAMPLE_BUSINESS_PRESETS.
  // ---------------------------------------------------------------------

  const loadBusiness = useCallback(async (businessId: string) => {
    setIsLoadingBusiness(true);
    try {
      const [biz, chk, lrn] = await Promise.all([
        api.fetchBusiness(businessId),
        api.fetchChecklists(businessId),
        api.fetchLearners(businessId, true),
      ]);
      setProfile(biz);
      setChecklists(chk);
      setLearners(lrn);
      setLoadError(null);
    } catch (err) {
      console.error('Failed to load business data', err);
      setLoadError('Could not reach the compliance backend. Confirm the server is running.');
    } finally {
      setIsLoadingBusiness(false);
    }
  }, []);

  const loadEverything = useCallback(async () => {
    setIsLoadingApp(true);
    try {
      const list = await api.fetchBusinesses();
      setBusinesses(list);
      const defaultId = list.find((b) => b.id === DEFAULT_BUSINESS_ID)?.id || list[0]?.id;
      if (defaultId) {
        await loadBusiness(defaultId);
      }
      setLoadError(null);
    } catch (err) {
      console.error('Failed to load businesses', err);
      setLoadError('Could not reach the compliance backend. Confirm the server is running.');
    } finally {
      setIsLoadingApp(false);
    }
  }, [loadBusiness]);

  useEffect(() => {
    loadEverything();
  }, [loadEverything]);

  // Switch Business
  const handleSelectBusinessId = async (businessId: string) => {
    if (!businessId || businessId === profile?.id) return;
    await loadBusiness(businessId);
    setActiveTab('overview');
    const target = businesses.find((b) => b.id === businessId);
    showToast(`Switched to ${target?.name || 'selected business'}`);
  };

  // Admin Portfolio -> jump into a specific client's workspace
  const handleAdminSelectBusiness = async (businessId: string) => {
    await loadBusiness(businessId);
    setActiveTab('overview');
  };

  // Update Profile
  const handleUpdateProfile = async (updated: Partial<BusinessProfile>) => {
    if (!profile) return;
    const previous = profile;
    const merged = { ...profile, ...updated };
    setProfile(merged);
    setBusinesses((prev) => prev.map((b) => (b.id === merged.id ? { ...b, ...updated } : b)));

    try {
      await api.updateBusiness(profile.id, merged);
    } catch (err) {
      console.error('Failed to save business profile', err);
      setProfile(previous);
      showToast('Could not save business profile changes', 'error');
      return;
    }

    // If sector changed, make sure the sector-specific statutory checklist
    // items for the new sector actually exist for this business.
    if (updated.sector && updated.sector !== previous.sector) {
      const sectorTemplates = SECTOR_SPECIFIC_CHECKLISTS[updated.sector] || [];
      const existingTitles = new Set(checklists.map((c) => c.title));
      const missingTemplates = sectorTemplates.filter((t) => !existingTitles.has(t.title));

      try {
        for (const template of missingTemplates) {
          await api.createChecklistItem(profile.id, {
            ...template,
            id: `chk-${profile.id}-${template.id}-${Date.now()}`,
            status: 'not_started',
            managerNotes: '',
            evidenceDocumented: false,
            attachments: [],
          });
        }
        if (missingTemplates.length > 0) {
          const refreshed = await api.fetchChecklists(profile.id);
          setChecklists(refreshed);
        }
      } catch (err) {
        console.error('Failed to refresh sector checklist templates', err);
      }

      showToast(
        `Switched sector to ${SECTOR_METADATA[updated.sector].name}. Regulatory audit standards updated.`
      );
    }
  };

  // Checklist updates
  const handleUpdateChecklistItem = async (id: string, updated: Partial<AuditChecklistItem>) => {
    if (!profile) return;
    const previous = checklists;
    setChecklists((prev) => prev.map((item) => (item.id === id ? { ...item, ...updated } : item)));

    try {
      await api.updateChecklist(profile.id, id, updated);
    } catch (err) {
      console.error('Failed to save checklist item', err);
      setChecklists(previous);
      showToast('Could not save checklist changes', 'error');
    }
  };

  const handleAddChecklistItem = async (newItem: AuditChecklistItem) => {
    if (!profile) return;
    try {
      await api.createChecklistItem(profile.id, newItem);
      setChecklists((prev) => [newItem, ...prev]);
      showToast(`Added checklist requirement: ${newItem.title}`);
    } catch (err) {
      console.error('Failed to add checklist item', err);
      showToast('Could not add the checklist requirement', 'error');
    }
  };

  // Learner operations
  const handleSaveLearner = async (learner: Learner) => {
    if (!profile) return;
    const exists = learners.some((l) => l.id === learner.id);

    try {
      if (exists) {
        await api.updateLearner(profile.id, learner.id, learner);
        setLearners((prev) => prev.map((l) => (l.id === learner.id ? learner : l)));
      } else {
        await api.createLearner(profile.id, learner);
        setLearners((prev) => [learner, ...prev]);
      }
      showToast(`Saved learner ${learner.name} (${learner.jobTitle})`);
    } catch (err) {
      console.error('Failed to save learner', err);
      showToast('Could not save this learner', 'error');
    }
  };

  const handleUpdateLearner = async (id: string, updated: Partial<Learner>) => {
    if (!profile) return;
    const previous = learners;
    const existing = learners.find((l) => l.id === id);
    if (!existing) return;
    const nextLearner = { ...existing, ...updated };
    setLearners((prev) => prev.map((l) => (l.id === id ? nextLearner : l)));

    try {
      await api.updateLearner(profile.id, id, nextLearner);
    } catch (err) {
      console.error('Failed to update learner', err);
      setLearners(previous);
      showToast('Could not save learner changes', 'error');
    }
  };

  const handleArchiveLearner = async (learnerId: string, reason: string) => {
    if (!profile) return;
    try {
      await api.archiveLearner(profile.id, learnerId, reason);
      const refreshed = await api.fetchLearners(profile.id, true);
      setLearners(refreshed);
      showToast('Learner archived');
    } catch (err) {
      console.error('Failed to archive learner', err);
      showToast('Could not archive learner', 'error');
    }
  };

  const handleRestoreLearner = async (learnerId: string) => {
    if (!profile) return;
    try {
      await api.restoreLearner(profile.id, learnerId);
      const refreshed = await api.fetchLearners(profile.id, true);
      setLearners(refreshed);
      showToast('Learner restored to active register');
    } catch (err) {
      console.error('Failed to restore learner', err);
      showToast('Could not restore learner', 'error');
    }
  };

  const handleSaveLearnerCourseRecord = async (record: LearnerCourseRecord) => {
    if (!profile || !selectedLearnerForEnrol) return;
    const learnerId = selectedLearnerForEnrol.id;

    try {
      await api.enrolCourse(profile.id, learnerId, record);
      const refreshed = await api.fetchLearners(profile.id, true);
      setLearners(refreshed);
      showToast(`Enrolled ${selectedLearnerForEnrol.name} in ${record.courseTitle}`);
    } catch (err) {
      console.error('Failed to save course record', err);
      showToast('Could not save this enrolment', 'error');
    }
  };

  // Batch Enrol Action for Course
  const handleBatchEnrolCourse = async (course: Course, targetLearnerIds: string[]) => {
    if (!profile) return;
    const targets = learners.filter(
      (l) =>
        targetLearnerIds.includes(l.id) &&
        !l.courses.some((c) => c.courseId === course.id && c.status === 'completed')
    );

    try {
      await Promise.all(
        targets.map((l) =>
          api.enrolCourse(profile.id, l.id, {
            courseId: course.id,
            courseTitle: course.title,
            status: 'in_progress',
            progressPercent: 15,
          })
        )
      );
      const refreshed = await api.fetchLearners(profile.id, true);
      setLearners(refreshed);
      showToast(`Enrolled ${targets.length} employees in ${course.title} via our LMS`);
    } catch (err) {
      console.error('Failed to batch enrol learners', err);
      showToast('Could not complete batch enrolment', 'error');
    }
  };

  // Quick enrol from Overview
  const handleQuickEnrolFromOverview = (courseId: string) => {
    const course = COURSES_CATALOG.find((c) => c.id === courseId);
    if (!course) return;

    const targetLearners = learners.filter((l) => {
      if (!course.targetRoles.includes(l.roleLevel)) return false;
      return !l.courses.some(
        (c) => c.courseId === course.id && (c.status === 'completed' || c.status === 'in_progress')
      );
    });

    handleBatchEnrolCourse(
      course,
      targetLearners.map((l) => l.id)
    );
  };

  // CSV Import
  const handleBulkImportSuccess = async () => {
    if (!profile) return;
    const refreshed = await api.fetchLearners(profile.id, true);
    setLearners(refreshed);
  };

  // Guided Onboarding
  const handleCompleteOnboarding = async (profileData: Partial<BusinessProfile>) => {
    await handleUpdateProfile(profileData);
    showToast('Business profile initialised. Statutory checklist set is ready.');
  };

  // Reset Demo Database
  const handleResetDemo = async () => {
    try {
      await api.resetDemoDatabase();
      showToast('Demo database reset to default seed state');
      await loadEverything();
    } catch (err) {
      console.error('Failed to reset demo database', err);
      showToast('Could not reset the demo database', 'error');
    }
  };

  // Audit calculation engine — recomputed whenever the underlying data changes
  const report = useMemo(() => {
    if (!profile) return null;
    return runComplianceAudit(profile, checklists, learners);
  }, [profile, checklists, learners]);

  const isViewer = currentRole === 'viewer';

  if (isLoadingApp) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="h-10 w-10 mx-auto rounded-xl bg-tertiary-900 animate-pulse" />
          <p className="text-sm font-semibold text-slate-500">
            Connecting to compliance database…
          </p>
        </div>
      </div>
    );
  }

  if (loadError && !profile) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6">
        <div className="max-w-md text-center space-y-3 bg-white border border-rose-200 rounded-xl p-6 shadow-sm">
          <p className="text-sm font-bold text-rose-700">Unable to load the compliance dashboard</p>
          <p className="text-xs text-slate-500">{loadError}</p>
          <button
            type="button"
            onClick={() => loadEverything()}
            className="mt-2 inline-flex items-center px-4 py-2 bg-tertiary-800 hover:bg-tertiary-700 text-white text-xs font-semibold rounded-lg"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!profile || !report) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Primary Header */}
      <Header
        currentProfile={profile}
        businesses={businesses}
        onSelectBusinessId={handleSelectBusinessId}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenReport={() => setShowReportModal(true)}
        onOpenOnboarding={() => setShowOnboarding(true)}
        onResetDemo={handleResetDemo}
        compliancePercent={report.overallScorePercent}
        currentRole={currentRole}
        onChangeRole={setCurrentRole}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {isLoadingBusiness && (
          <div className="mb-4 text-xs font-semibold text-slate-500 bg-white border border-slate-200 rounded-lg px-3 py-2">
            Loading business data…
          </div>
        )}

        {activeTab === 'portfolio' && currentRole === 'admin' && (
          <AdminPortfolioView onSelectBusiness={handleAdminSelectBusiness} />
        )}

        {activeTab === 'regulatory' && currentRole === 'admin' && <AdminRegulatoryView />}

        {activeTab === 'overview' && (
          <AuditOverview
            report={report}
            profile={profile}
            onNavigateToTab={setActiveTab}
            onQuickEnrolLearners={handleQuickEnrolFromOverview}
            readOnly={isViewer}
          />
        )}

        {activeTab === 'business' && (
          <BusinessProfileView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            registeredLearnerCount={learners.length}
            readOnly={isViewer}
          />
        )}

        {activeTab === 'checklists' && (
          <ManagerChecklistsView
            checklists={checklists}
            onUpdateItem={handleUpdateChecklistItem}
            onAddItem={handleAddChecklistItem}
            readOnly={isViewer}
          />
        )}

        {activeTab === 'learners' && (
          <LearnersRegisterView
            learners={learners}
            profile={profile}
            onAddLearner={handleSaveLearner}
            onUpdateLearner={handleUpdateLearner}
            onArchiveLearner={handleArchiveLearner}
            onRestoreLearner={handleRestoreLearner}
            onBulkImportSuccess={handleBulkImportSuccess}
            onOpenEnrolModal={(learner) => {
              setSelectedLearnerForEnrol(learner);
            }}
            onOpenAddModal={() => {
              setEditingLearner(null);
              setShowLearnerModal(true);
            }}
            readOnly={isViewer}
          />
        )}

        {activeTab === 'solutions' && (
          <TrainingSolutionsView
            learners={learners}
            profile={profile}
            onEnrolLearnerInCourse={(learnerId, course) =>
              handleBatchEnrolCourse(course, [learnerId])
            }
            onBatchEnrolCourse={handleBatchEnrolCourse}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500 mt-12 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-3">
          <div>
            <span className="font-semibold text-slate-700">
              UK Compliance Status Checker & Audit Preparation System
            </span>
            <span className="mx-2">•</span>
            <span>September 2026 Regulatory Data</span>
          </div>
          <div className="flex items-center space-x-4 text-[11px] text-slate-400">
            <span>FSA FHRS Brand Standard</span>
            <span>•</span>
            <span>CQC 2026 Framework</span>
            <span>•</span>
            <span>FCA SM&CR & CASS 15</span>
            <span>•</span>
            <span>HSE CDM 2015 & Border Security Act 2025</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <LearnerModal
        profile={profile}
        isOpen={showLearnerModal}
        onClose={() => {
          setShowLearnerModal(false);
          setEditingLearner(null);
        }}
        onSave={handleSaveLearner}
        initialLearner={editingLearner}
      />

      {selectedLearnerForEnrol && (
        <EnrolCourseModal
          learner={selectedLearnerForEnrol}
          profile={profile}
          isOpen={!!selectedLearnerForEnrol}
          onClose={() => setSelectedLearnerForEnrol(null)}
          onSaveRecord={handleSaveLearnerCourseRecord}
        />
      )}

      <AuditReportModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        profile={profile}
        report={report}
        checklists={checklists}
        learners={learners}
      />

      <GuidedOnboardingModal
        isOpen={showOnboarding}
        onClose={() => setShowOnboarding(false)}
        onComplete={handleCompleteOnboarding}
        currentProfile={profile}
      />
    </div>
  );
}
